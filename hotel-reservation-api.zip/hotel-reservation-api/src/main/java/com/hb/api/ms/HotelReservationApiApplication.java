package com.hb.api.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelReservationApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(HotelReservationApiApplication.class, args);
    }

}
