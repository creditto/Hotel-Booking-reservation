package com.hb.api.ms.validator;

import org.junit.jupiter.api.Test;

class ReservationValidatorTest {

    @Test
    void validateReservationPOST() {
    }

    @Test
    void validateId() {
    }

    @Test
    void validateDates() {
    }

    @Test
    void validateGuest() {
    }
}